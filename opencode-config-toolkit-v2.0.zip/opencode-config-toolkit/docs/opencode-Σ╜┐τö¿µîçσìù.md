# OpenCode 自定义 API 使用指南

## 快速开始

### 最简单的方式：使用环境变量

如果你的 API 兼容 Anthropic 格式，这是最简单的配置方式：

```bash
# 1. 创建配置文件
cat > ~/.opencode_env << 'EOF'
export ANTHROPIC_BASE_URL="https://tiantianai.pro/v1"
export ANTHROPIC_API_KEY="sk-NFnWE5NQfs2tcGuVeIIVsSNA7LZMLcBGzV4HVJFioiWn3O0c"
EOF

# 2. 永久配置（添加到 shell 配置）
echo 'source ~/.opencode_env' >> ~/.zshrc
source ~/.zshrc

# 3. 启动 OpenCode
opencode
```

**优点**：
- ✅ 无需编写 JSON 配置
- ✅ 无需运行 `opencode auth login`
- ✅ 配置简单快速

---

## 1. 启动 OpenCode 并指定模型

### 方法 1: 使用命令行参数指定模型

```bash
# 启动 TUI 界面并指定模型
source ~/.opencode_env && opencode -m anthropic/claude-opus-4-5-20251101

# 或使用启动脚本
~/opencode-custom-api.sh -m anthropic/claude-opus-4-5-20251101
```

### 方法 2: 直接运行命令

```bash
# 运行单次命令
source ~/.opencode_env && opencode run -m anthropic/claude-opus-4-5-20251101 "你的问题"

# 示例
source ~/.opencode_env && opencode run -m anthropic/claude-opus-4-5-20251101 "帮我写一个 Python 脚本"
```

### 方法 3: 在 TUI 界面中切换模型

启动 opencode 后，在交互界面中：
1. 按 `/` 键打开命令面板
2. 输入 `model` 或使用 `/model` 命令
3. 选择你想要的模型

## 2. 可用的模型列表

你的自定义 API 支持以下模型：

```
anthropic/claude-opus-4-5-20251101      # 你在 curl 中使用的模型
anthropic/claude-opus-4-5
anthropic/claude-opus-4-1
anthropic/claude-sonnet-4-5
anthropic/claude-sonnet-4-5-20250929
anthropic/claude-haiku-4-5
... 等等
```

## 3. 查看可用模型

```bash
source ~/.opencode_env && opencode models
```

## 4. 常用命令

```bash
# 启动 TUI 界面
source ~/.opencode_env && opencode

# 启动并指定模型
source ~/.opencode_env && opencode -m anthropic/claude-opus-4-5-20251101

# 继续上次会话
source ~/.opencode_env && opencode -c

# 启动 Web 界面
source ~/.opencode_env && opencode web

# 查看会话历史
source ~/.opencode_env && opencode session list
```

## 5. 永久配置（推荐）

将以下内容添加到 `~/.zshrc` 或 `~/.bashrc`：

```bash
# OpenCode 自定义 API
source ~/.opencode_env

# 可选：创建别名
alias oc='opencode'
alias oc-opus='opencode -m anthropic/claude-opus-4-5-20251101'
alias oc-sonnet='opencode -m anthropic/claude-sonnet-4-5'
```

然后重启终端或运行：
```bash
source ~/.zshrc  # 或 source ~/.bashrc
```

## 6. 验证配置

```bash
# 测试 API 连接
curl -X POST https://tiantianai.pro/v1/messages \
    -H "Content-Type: application/json" \
    -H "x-api-key: sk-NFnWE5NQfs2tcGuVeIIVsSNA7LZMLcBGzV4HVJFioiWn3O0c" \
    -d '{
      "model": "claude-opus-4-5-20251101",
      "max_tokens": 100,
      "messages": [{"role": "user", "content": "Hello"}]
    }'
```

## 7. 故障排除

如果遇到问题：

1. 检查环境变量是否设置：
   ```bash
   echo $ANTHROPIC_BASE_URL
   echo $ANTHROPIC_API_KEY
   ```

2. 验证 API 是否可用：
   ```bash
   curl -X POST $ANTHROPIC_BASE_URL/messages \
       -H "Content-Type: application/json" \
       -H "x-api-key: $ANTHROPIC_API_KEY" \
       -d '{
         "model": "claude-opus-4-5-20251101",
         "max_tokens": 100,
         "messages": [{"role": "user", "content": "Hello"}]
       }'
   ```

3. 查看可用模型：
   ```bash
   opencode models
   ```

4. 查看日志：
   ```bash
   opencode --print-logs
   ```

5. 查看日志文件：
   ```bash
   ls -lt ~/.local/share/opencode/log/ | head -5
   cat ~/.local/share/opencode/log/$(ls -t ~/.local/share/opencode/log/ | head -1)
   ```

## 8. 常见问题

### Q1: 环境变量配置后不生效？

**解决方法**：
```bash
# 确保已经 source 配置文件
source ~/.zshrc  # 或 source ~/.bashrc

# 验证环境变量
echo $ANTHROPIC_BASE_URL
echo $ANTHROPIC_API_KEY

# 如果为空，检查配置文件是否正确
cat ~/.opencode_env
```

### Q2: 如何在不同项目中使用不同的 API？

**方法 1：使用项目级环境变量**
```bash
# 在项目目录创建 .env 文件
cat > .env << 'EOF'
export ANTHROPIC_BASE_URL="https://project-specific-api.com/v1"
export ANTHROPIC_API_KEY="project-specific-key"
EOF

# 启动时加载
source .env && opencode
```

**方法 2：使用不同的启动脚本**
```bash
# 创建项目专用脚本
cat > ~/opencode-project-a.sh << 'EOF'
#!/bin/bash
export ANTHROPIC_BASE_URL="https://api-a.com/v1"
export ANTHROPIC_API_KEY="key-a"
opencode "$@"
EOF

chmod +x ~/opencode-project-a.sh
```

### Q3: 如何临时切换到不同的 API？

```bash
# 临时使用不同的 API（仅当前命令）
ANTHROPIC_BASE_URL="https://other-api.com/v1" \
ANTHROPIC_API_KEY="other-key" \
opencode
```

### Q4: 环境变量方式和配置文件方式可以同时使用吗？

可以，但环境变量的优先级更高。如果同时设置了环境变量和配置文件，OpenCode 会优先使用环境变量。

### Q5: 如何查看当前使用的是哪个 API？

```bash
# 查看环境变量
echo "Base URL: $ANTHROPIC_BASE_URL"
echo "API Key: ${ANTHROPIC_API_KEY:0:20}..."

# 在 OpenCode 中查看模型列表
opencode models
```

## 9. 高级技巧

### 技巧 1: 创建多个 API 配置快速切换

```bash
# 在 ~/.zshrc 中添加
alias oc-api1='ANTHROPIC_BASE_URL="https://api1.com/v1" ANTHROPIC_API_KEY="key1" opencode'
alias oc-api2='ANTHROPIC_BASE_URL="https://api2.com/v1" ANTHROPIC_API_KEY="key2" opencode'
alias oc-local='ANTHROPIC_BASE_URL="http://localhost:8000/v1" ANTHROPIC_API_KEY="local" opencode'
```

### 技巧 2: 使用函数动态选择 API

```bash
# 在 ~/.zshrc 中添加
oc() {
    case "$1" in
        prod)
            export ANTHROPIC_BASE_URL="https://prod-api.com/v1"
            export ANTHROPIC_API_KEY="prod-key"
            ;;
        dev)
            export ANTHROPIC_BASE_URL="https://dev-api.com/v1"
            export ANTHROPIC_API_KEY="dev-key"
            ;;
        local)
            export ANTHROPIC_BASE_URL="http://localhost:8000/v1"
            export ANTHROPIC_API_KEY="local-key"
            ;;
        *)
            echo "Usage: oc [prod|dev|local]"
            return 1
            ;;
    esac
    shift
    opencode "$@"
}

# 使用方式
oc prod              # 使用生产环境 API
oc dev -m anthropic/claude-opus-4-5-20251101  # 使用开发环境 API 和指定模型
oc local             # 使用本地 API
```

### 技巧 3: 自动记录 API 使用情况

```bash
# 创建带日志的启动脚本
cat > ~/opencode-with-log.sh << 'EOF'
#!/bin/bash
LOG_FILE=~/.opencode_usage.log
echo "[$(date)] Starting OpenCode with API: $ANTHROPIC_BASE_URL" >> $LOG_FILE
opencode "$@"
echo "[$(date)] OpenCode session ended" >> $LOG_FILE
EOF

chmod +x ~/opencode-with-log.sh
```

### 技巧 4: 使用 direnv 实现项目自动配置

安装 direnv：
```bash
# macOS
brew install direnv

# 添加到 shell 配置
echo 'eval "$(direnv hook zsh)"' >> ~/.zshrc
```

在项目目录创建 `.envrc`：
```bash
cat > .envrc << 'EOF'
export ANTHROPIC_BASE_URL="https://project-api.com/v1"
export ANTHROPIC_API_KEY="project-key"
EOF

# 允许加载
direnv allow
```

现在每次进入项目目录，环境变量会自动加载！

## 10. 配置对比

### 环境变量 vs 配置文件

| 特性 | 环境变量 | 配置文件 |
|------|---------|---------|
| 配置难度 | ⭐ 简单 | ⭐⭐⭐ 复杂 |
| 需要 auth login | ❌ 不需要 | ✅ 需要 |
| 支持多 provider | ❌ 不支持 | ✅ 支持 |
| 支持 OpenAI 格式 | ❌ 不支持 | ✅ 支持 |
| 支持 Anthropic 格式 | ✅ 支持 | ✅ 支持 |
| 快速切换 API | ✅ 容易 | ❌ 困难 |
| 项目级配置 | ✅ 容易 | ❌ 困难 |

**推荐使用场景**：
- 单一 Anthropic API → 环境变量 ⭐⭐⭐⭐⭐
- 多个 provider → 配置文件 ⭐⭐⭐⭐
- 需要 OpenAI 格式 → 配置文件 ⭐⭐⭐⭐
- 频繁切换 API → 环境变量 + 别名 ⭐⭐⭐⭐⭐
