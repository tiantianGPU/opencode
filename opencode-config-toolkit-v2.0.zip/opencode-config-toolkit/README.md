# OpenCode 配置工具包

> 让 OpenCode 配置变得简单！支持 Windows、macOS、Linux

## 🎯 这是什么？

这是一个帮助你快速配置 OpenCode 自定义 API 的工具包，包含：
- 📖 详细的配置文档
- 🔧 一键配置脚本
- 🚀 快捷启动脚本
- 🖱️ Windows 右键菜单集成

## ⚡ 快速开始（3 分钟）

### Windows 用户

**方式 1：一键配置（最简单）**

1. 打开 `scripts/windows/` 文件夹
2. 右键 `setup-opencode-windows.ps1`
3. 选择「使用 PowerShell 运行」
4. 按提示输入你的 API 信息
5. 完成！

**方式 2：双击启动**

1. 编辑 `scripts/windows/opencode-start-windows.bat`
2. 修改里面的 API 信息（第 5-6 行）
3. 双击运行
4. OpenCode 自动启动！

### macOS/Linux 用户

**方式 1：使用环境变量**

```bash
# 1. 编辑配置文件
nano scripts/macos-linux/.opencode_env
# 修改 API 信息

# 2. 加载配置
echo 'source ~/opencode-config-toolkit/scripts/macos-linux/.opencode_env' >> ~/.zshrc
source ~/.zshrc

# 3. 启动
opencode
```

**方式 2：使用启动脚本**

```bash
# 1. 编辑脚本
nano scripts/macos-linux/opencode-custom-api.sh
# 修改 API 信息

# 2. 添加执行权限
chmod +x scripts/macos-linux/opencode-custom-api.sh

# 3. 运行
./scripts/macos-linux/opencode-custom-api.sh
```

## 📁 文件结构

```
opencode-config-toolkit/
├── README.md                          # 本文件（快速开始）
├── 使用指南.md                        # 详细使用说明
├── docs/                              # 📖 文档目录
│   ├── OpenCode安装教程.md            # 完整安装教程
│   ├── opencode-使用指南.md           # 使用指南
│   ├── OpenCode-Windows配置完全指南.md # Windows 详细指南 ⭐
│   └── OpenCode-Windows工具包说明.md  # 工具包说明
├── scripts/                           # 🔧 脚本目录
│   ├── windows/                       # Windows 脚本
│   │   ├── setup-opencode-windows.ps1      # 一键配置 ⭐
│   │   ├── opencode-start-windows.ps1      # PowerShell 启动
│   │   └── opencode-start-windows.bat      # 批处理启动
│   └── macos-linux/                   # macOS/Linux 脚本
│       ├── opencode-custom-api.sh          # 启动脚本
│       └── .opencode_env                   # 环境变量配置
└── registry/                          # 🖱️ Windows 注册表文件
    ├── add-opencode-context-menu.reg       # 添加右键菜单
    └── remove-opencode-context-menu.reg    # 删除右键菜单
```

## 📖 详细文档

### 新手必读

1. **使用指南.md** - 从这里开始！
   - 3 分钟快速配置
   - 图文并茂的步骤说明
   - 常见问题解答

### Windows 用户

2. **docs/OpenCode-Windows配置完全指南.md** ⭐ 强烈推荐
   - 超详细的 Windows 配置指南
   - 6 种启动方式
   - 8 个常见问题 + 5 个实用技巧

### 所有用户

3. **docs/OpenCode安装教程.md**
   - 跨平台安装教程
   - 环境变量 vs 配置文件对比
   - 20 个常见问题解答

4. **docs/opencode-使用指南.md**
   - 模型切换方法
   - 高级使用技巧
   - 配置对比表

## 🔧 工具说明

### Windows 工具

| 文件 | 用途 | 使用方法 |
|------|------|---------|
| `setup-opencode-windows.ps1` | 一键配置 ⭐ | 右键 → 使用 PowerShell 运行 |
| `opencode-start-windows.ps1` | PowerShell 启动 | 编辑 API 信息后运行 |
| `opencode-start-windows.bat` | 批处理启动 | 编辑 API 信息后双击 |
| `add-opencode-context-menu.reg` | 添加右键菜单 | 编辑 API 信息后双击 |
| `remove-opencode-context-menu.reg` | 删除右键菜单 | 双击运行 |

### macOS/Linux 工具

| 文件 | 用途 | 使用方法 |
|------|------|---------|
| `.opencode_env` | 环境变量配置 | 编辑后 source 到 shell 配置 |
| `opencode-custom-api.sh` | 启动脚本 | 编辑后添加执行权限运行 |

## ❓ 常见问题

### Q1: 我应该用哪个文件？

**Windows 新手**：
- 使用 `scripts/windows/setup-opencode-windows.ps1`（一键配置）
- 然后使用 `scripts/windows/opencode-start-windows.bat`（双击启动）

**Windows 高级用户**：
- 手动设置环境变量（参考文档）
- 或使用 `scripts/windows/opencode-start-windows.ps1`

**macOS/Linux 用户**：
- 使用 `scripts/macos-linux/.opencode_env`（推荐）
- 或使用 `scripts/macos-linux/opencode-custom-api.sh`

### Q2: 需要修改哪些文件？

**必须修改的文件**（替换为你的 API 信息）：

Windows：
- `scripts/windows/opencode-start-windows.ps1`（第 4-5 行）
- `scripts/windows/opencode-start-windows.bat`（第 5-6 行）
- `registry/add-opencode-context-menu.reg`（第 10 行）

macOS/Linux：
- `scripts/macos-linux/.opencode_env`（第 2-3 行）
- `scripts/macos-linux/opencode-custom-api.sh`（第 6-7 行）

**不需要修改的文件**：
- `scripts/windows/setup-opencode-windows.ps1`（交互式输入）
- `registry/remove-opencode-context-menu.reg`（删除脚本）
- 所有 `.md` 文档文件

### Q3: PowerShell 脚本无法执行？

**错误信息**：`无法加载文件，因为在此系统上禁止运行脚本`

**解决方法**：

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Q4: 如何验证配置成功？

**Windows**：
```powershell
# 检查环境变量
echo $env:ANTHROPIC_BASE_URL
echo $env:ANTHROPIC_API_KEY

# 查看可用模型
opencode models
```

**macOS/Linux**：
```bash
# 检查环境变量
echo $ANTHROPIC_BASE_URL
echo $ANTHROPIC_API_KEY

# 查看可用模型
opencode models
```

如果看到 `anthropic/` 开头的模型列表，说明配置成功！

### Q5: 我还是不会配置怎么办？

1. 查看 `使用指南.md`（最简单的说明）
2. 查看 `docs/OpenCode-Windows配置完全指南.md`（Windows 详细指南）
3. 查看 `docs/OpenCode安装教程.md`（完整教程）

## 🎯 推荐使用流程

### 第一次使用

1. **阅读文档**（5 分钟）
   - 打开 `使用指南.md`
   - 了解基本概念

2. **配置 API**（3 分钟）
   - Windows：运行 `scripts/windows/setup-opencode-windows.ps1`
   - macOS/Linux：编辑 `scripts/macos-linux/.opencode_env`

3. **启动 OpenCode**（1 分钟）
   - Windows：双击 `scripts/windows/opencode-start-windows.bat`
   - macOS/Linux：运行 `./scripts/macos-linux/opencode-custom-api.sh`

4. **开始使用**
   - 输入你的编程问题
   - 享受 AI 编程助手！

### 日常使用

**Windows**：
- 双击桌面快捷方式（如果已创建）
- 或双击 `opencode-start-windows.bat`
- 或在文件夹右键选择"在此处打开 OpenCode"（如果已添加）

**macOS/Linux**：
- 直接在终端输入 `opencode`（如果已配置环境变量）
- 或运行启动脚本

## 🌟 高级功能

### Windows 右键菜单

1. 编辑 `registry/add-opencode-context-menu.reg`
2. 修改第 10 行的 API Key
3. 双击导入注册表
4. 在任意文件夹空白处右键 → "在此处打开 OpenCode"

### 快速切换模型

**启动时指定**：
```bash
opencode -m anthropic/claude-opus-4-5-20251101
opencode -m anthropic/claude-sonnet-4-5
```

**在界面中切换**：
- 启动后按 `/` 键
- 输入 `model`
- 选择模型

### 切换不同的 API

参考 `docs/OpenCode-Windows配置完全指南.md` 的高级配置部分。

## 📞 获取帮助

如果遇到问题：

1. **查看文档**
   - `使用指南.md`（快速参考）
   - `docs/OpenCode-Windows配置完全指南.md`（详细指南）
   - `docs/OpenCode安装教程.md`（完整教程）

2. **常见问题**
   - 每个文档都有详细的常见问题解答
   - 涵盖 90% 的使用问题

3. **在线支持**
   - OpenCode 官方文档：https://opencode.ai/docs
   - GitHub Issues：https://github.com/anomalyco/opencode/issues

## 📝 更新日志

### v2.0 (2026-01-28)

**重大更新**：
- ✅ 新增环境变量配置方式（推荐）
- ✅ 新增一键配置脚本
- ✅ 新增 Windows 完全配置指南
- ✅ 配置时间从 10 分钟缩短到 3 分钟
- ✅ 新增 8 个 Windows 专属问题解答
- ✅ 新增 6 种启动方式

**文件统计**：
- 文档：6 个
- 脚本：5 个
- 注册表文件：2 个
- 总计：13 个文件

## 🏆 特点

- ✅ **简单易用**：3 分钟完成配置
- ✅ **详细文档**：超过 3000 行文档
- ✅ **多种方式**：6 种启动方式可选
- ✅ **跨平台**：支持 Windows、macOS、Linux
- ✅ **完全免费**：所有工具和文档免费使用

## 📄 许可证

本工具包中的所有文档和脚本均可自由使用和修改。

---

**让 OpenCode 配置变得简单，让 AI 编程触手可及！** 🚀

**最后更新**：2026-01-28
**版本**：2.0
