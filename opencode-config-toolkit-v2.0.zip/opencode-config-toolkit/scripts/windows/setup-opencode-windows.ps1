# OpenCode 一键配置脚本
# 使用方法：右键 → 使用 PowerShell 运行

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   OpenCode 环境变量一键配置脚本" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 检查是否以管理员身份运行（可选）
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "提示：未以管理员身份运行，将设置用户级环境变量" -ForegroundColor Yellow
    Write-Host ""
}

# 提示输入 API 信息
Write-Host "请输入 API 配置信息：" -ForegroundColor Cyan
Write-Host ""

$baseUrl = Read-Host "API Base URL (直接回车使用默认: https://tiantianai.pro/v1)"
if ([string]::IsNullOrWhiteSpace($baseUrl)) {
    $baseUrl = "https://tiantianai.pro/v1"
}

Write-Host ""
$apiKey = Read-Host "API Key (必填)"
if ([string]::IsNullOrWhiteSpace($apiKey)) {
    Write-Host ""
    Write-Host "错误：API Key 不能为空！" -ForegroundColor Red
    Write-Host ""
    pause
    exit 1
}

# 确认信息
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "配置信息确认：" -ForegroundColor Yellow
Write-Host "  Base URL: $baseUrl" -ForegroundColor White
Write-Host "  API Key: $($apiKey.Substring(0, [Math]::Min(20, $apiKey.Length)))..." -ForegroundColor White
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$confirm = Read-Host "确认配置？(Y/N)"
if ($confirm -ne "Y" -and $confirm -ne "y") {
    Write-Host "已取消配置" -ForegroundColor Yellow
    pause
    exit 0
}

# 设置环境变量
Write-Host ""
Write-Host "正在设置环境变量..." -ForegroundColor Yellow

try {
    # 设置用户级环境变量
    [System.Environment]::SetEnvironmentVariable('ANTHROPIC_BASE_URL', $baseUrl, 'User')
    [System.Environment]::SetEnvironmentVariable('ANTHROPIC_API_KEY', $apiKey, 'User')

    # 在当前会话中也生效
    $env:ANTHROPIC_BASE_URL = $baseUrl
    $env:ANTHROPIC_API_KEY = $apiKey

    Write-Host "✓ 环境变量设置成功！" -ForegroundColor Green
    Write-Host ""

    # 验证设置
    Write-Host "验证环境变量..." -ForegroundColor Yellow
    $savedBaseUrl = [System.Environment]::GetEnvironmentVariable('ANTHROPIC_BASE_URL', 'User')
    $savedApiKey = [System.Environment]::GetEnvironmentVariable('ANTHROPIC_API_KEY', 'User')

    if ($savedBaseUrl -eq $baseUrl -and $savedApiKey -eq $apiKey) {
        Write-Host "✓ 环境变量验证成功！" -ForegroundColor Green
    } else {
        Write-Host "⚠ 环境变量验证失败，请手动检查" -ForegroundColor Yellow
    }

    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "配置完成！" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""

    # 检查 OpenCode 是否已安装
    Write-Host "检查 OpenCode 安装状态..." -ForegroundColor Yellow
    if (Get-Command opencode -ErrorAction SilentlyContinue) {
        Write-Host "✓ OpenCode 已安装" -ForegroundColor Green
        Write-Host ""
        Write-Host "查看可用模型：" -ForegroundColor Cyan
        Write-Host ""
        opencode models
        Write-Host ""
        Write-Host "========================================" -ForegroundColor Cyan
        Write-Host "下一步：" -ForegroundColor Yellow
        Write-Host "  1. 重启 PowerShell 使环境变量在所有窗口生效" -ForegroundColor White
        Write-Host "  2. 运行 'opencode' 启动 OpenCode" -ForegroundColor White
        Write-Host "  3. 或运行 'opencode -m anthropic/claude-opus-4-5-20251101' 指定模型" -ForegroundColor White
        Write-Host "========================================" -ForegroundColor Cyan
    } else {
        Write-Host "⚠ OpenCode 未安装" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "请先安装 OpenCode：" -ForegroundColor Cyan
        Write-Host "  npm install -g opencode-ai@latest" -ForegroundColor White
        Write-Host ""
        Write-Host "或使用其他安装方式：" -ForegroundColor Cyan
        Write-Host "  scoop install opencode" -ForegroundColor White
        Write-Host "  choco install opencode" -ForegroundColor White
    }

} catch {
    Write-Host ""
    Write-Host "✗ 设置失败：$($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    Write-Host "请尝试手动设置：" -ForegroundColor Yellow
    Write-Host "  1. 按 Win + R，输入 sysdm.cpl" -ForegroundColor White
    Write-Host "  2. 点击「高级」→「环境变量」" -ForegroundColor White
    Write-Host "  3. 在「用户变量」中添加：" -ForegroundColor White
    Write-Host "     ANTHROPIC_BASE_URL = $baseUrl" -ForegroundColor White
    Write-Host "     ANTHROPIC_API_KEY = $apiKey" -ForegroundColor White
}

Write-Host ""
pause
