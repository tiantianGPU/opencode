# OpenCode Windows 配置完全指南

> 专为 Windows 10/11 用户编写的详细配置教程

## 📋 目录

- [快速开始（3 分钟配置）](#快速开始3-分钟配置)
- [方法对比](#方法对比)
- [方法 1：环境变量配置（推荐）](#方法-1环境变量配置推荐)
- [方法 2：配置文件方式](#方法-2配置文件方式)
- [高级配置](#高级配置)
- [常见问题](#常见问题)
- [实用技巧](#实用技巧)

---

## 🚀 快速开始（3 分钟配置）

### 最简单的配置方式

**步骤 1：设置环境变量**

按 `Win + R`，输入 `sysdm.cpl`，回车

1. 点击「高级」→「环境变量」
2. 在「用户变量」区域点击「新建」

添加两个变量：

| 变量名 | 变量值 |
|--------|--------|
| `ANTHROPIC_BASE_URL` | `https://tiantianai.pro/v1` |
| `ANTHROPIC_API_KEY` | `你的 API Key` |

3. 点击「确定」关闭所有对话框
4. **重启 PowerShell**

**步骤 2：验证配置**

打开新的 PowerShell 窗口：

```powershell
# 检查环境变量
echo $env:ANTHROPIC_BASE_URL
echo $env:ANTHROPIC_API_KEY

# 查看可用模型
opencode models
```

**步骤 3：启动 OpenCode**

```powershell
opencode
```

✅ 完成！现在你可以使用 OpenCode 了。

---

## 📊 方法对比

| 特性 | 环境变量方式 | 配置文件方式 |
|------|-------------|-------------|
| 配置难度 | ⭐ 简单 | ⭐⭐⭐ 复杂 |
| 配置时间 | 3 分钟 | 10 分钟 |
| 需要 auth login | ❌ 不需要 | ✅ 需要 |
| 需要 JSON 配置 | ❌ 不需要 | ✅ 需要 |
| 支持多 provider | ❌ 不支持 | ✅ 支持 |
| 支持 OpenAI 格式 | ❌ 不支持 | ✅ 支持 |
| 支持 Anthropic 格式 | ✅ 支持 | ✅ 支持 |
| 快速切换 API | ✅ 容易 | ❌ 困难 |
| 适合新手 | ✅ 推荐 | ❌ 不推荐 |

**推荐选择**：
- 🌟 **新手用户** → 环境变量方式
- 🌟 **只用一个 API** → 环境变量方式
- 🌟 **需要多个 provider** → 配置文件方式
- 🌟 **需要 OpenAI 格式** → 配置文件方式

---

## 🌟 方法 1：环境变量配置（推荐）

### 方式 A：图形界面设置（推荐新手）

#### 详细步骤（带截图说明）

**1. 打开系统属性**

- 按 `Win + R`
- 输入 `sysdm.cpl`
- 按回车

**2. 进入环境变量设置**

- 点击「高级」选项卡
- 点击「环境变量」按钮

**3. 添加第一个变量**

- 在「用户变量」区域点击「新建」
- 变量名：`ANTHROPIC_BASE_URL`
- 变量值：`https://tiantianai.pro/v1`
- 点击「确定」

**4. 添加第二个变量**

- 再次点击「新建」
- 变量名：`ANTHROPIC_API_KEY`
- 变量值：`sk-NFnWE5NQfs2tcGuVeIIVsSNA7LZMLcBGzV4HVJFioiWn3O0c`
- 点击「确定」

**5. 保存并生效**

- 点击「确定」关闭所有对话框
- **重启 PowerShell 或 CMD**（必须！）

#### 验证配置

```powershell
# 打开新的 PowerShell 窗口
# 检查环境变量
echo $env:ANTHROPIC_BASE_URL
echo $env:ANTHROPIC_API_KEY

# 应该看到你设置的值
```

### 方式 B：PowerShell 命令设置（推荐高级用户）

**以管理员身份运行 PowerShell**，执行：

```powershell
# 设置环境变量（永久生效）
[System.Environment]::SetEnvironmentVariable('ANTHROPIC_BASE_URL', 'https://tiantianai.pro/v1', 'User')
[System.Environment]::SetEnvironmentVariable('ANTHROPIC_API_KEY', 'sk-NFnWE5NQfs2tcGuVeIIVsSNA7LZMLcBGzV4HVJFioiWn3O0c', 'User')

# 验证设置
[System.Environment]::GetEnvironmentVariable('ANTHROPIC_BASE_URL', 'User')
[System.Environment]::GetEnvironmentVariable('ANTHROPIC_API_KEY', 'User')

# 在当前会话中立即生效
$env:ANTHROPIC_BASE_URL = [System.Environment]::GetEnvironmentVariable('ANTHROPIC_BASE_URL', 'User')
$env:ANTHROPIC_API_KEY = [System.Environment]::GetEnvironmentVariable('ANTHROPIC_API_KEY', 'User')
```

### 方式 C：一键配置脚本

创建 `setup-opencode.ps1` 文件：

```powershell
# OpenCode 一键配置脚本
# 使用方法：右键 → 使用 PowerShell 运行

Write-Host "OpenCode 环境变量配置脚本" -ForegroundColor Green
Write-Host "================================" -ForegroundColor Green
Write-Host ""

# 提示输入 API 信息
$baseUrl = Read-Host "请输入 API Base URL (默认: https://tiantianai.pro/v1)"
if ([string]::IsNullOrWhiteSpace($baseUrl)) {
    $baseUrl = "https://tiantianai.pro/v1"
}

$apiKey = Read-Host "请输入 API Key"
if ([string]::IsNullOrWhiteSpace($apiKey)) {
    Write-Host "错误：API Key 不能为空！" -ForegroundColor Red
    pause
    exit
}

# 设置环境变量
Write-Host ""
Write-Host "正在设置环境变量..." -ForegroundColor Yellow

try {
    [System.Environment]::SetEnvironmentVariable('ANTHROPIC_BASE_URL', $baseUrl, 'User')
    [System.Environment]::SetEnvironmentVariable('ANTHROPIC_API_KEY', $apiKey, 'User')

    # 在当前会话中生效
    $env:ANTHROPIC_BASE_URL = $baseUrl
    $env:ANTHROPIC_API_KEY = $apiKey

    Write-Host "✓ 环境变量设置成功！" -ForegroundColor Green
    Write-Host ""
    Write-Host "配置信息：" -ForegroundColor Cyan
    Write-Host "  Base URL: $baseUrl" -ForegroundColor White
    Write-Host "  API Key: $($apiKey.Substring(0, [Math]::Min(20, $apiKey.Length)))..." -ForegroundColor White
    Write-Host ""
    Write-Host "验证配置..." -ForegroundColor Yellow

    # 测试 opencode 命令
    if (Get-Command opencode -ErrorAction SilentlyContinue) {
        Write-Host "✓ OpenCode 已安装" -ForegroundColor Green
        Write-Host ""
        Write-Host "查看可用模型：" -ForegroundColor Cyan
        opencode models
    } else {
        Write-Host "⚠ OpenCode 未安装，请先安装 OpenCode" -ForegroundColor Yellow
        Write-Host "安装命令：npm install -g opencode-ai@latest" -ForegroundColor White
    }

} catch {
    Write-Host "✗ 设置失败：$($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "配置完成！请重启 PowerShell 使环境变量在所有窗口生效。" -ForegroundColor Green
Write-Host ""
pause
```

**使用方法**：
1. 保存为 `setup-opencode.ps1`
2. 右键文件 → 使用 PowerShell 运行
3. 按提示输入信息
4. 完成！

### 临时使用（不永久配置）

如果只想临时测试：

```powershell
# 仅在当前 PowerShell 会话生效
$env:ANTHROPIC_BASE_URL = "https://tiantianai.pro/v1"
$env:ANTHROPIC_API_KEY = "your-api-key"

# 启动 OpenCode
opencode
```

---

## 📋 方法 2：配置文件方式

### 适用场景

- 需要同时配置多个 provider（OpenAI + Claude）
- 需要使用 OpenAI 格式的 API
- 需要更灵活的模型配置

### 配置步骤

**步骤 1：创建配置文件**

在用户目录创建 `.opencode.json`：

```powershell
# 使用记事本创建配置文件
notepad $HOME\.opencode.json
```

**步骤 2：填写配置内容**

选择适合你的配置方式：

#### 配置方式 1：Anthropic 格式（适合 Claude 模型）

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "myproxy": {
      "npm": "@ai-sdk/anthropic",
      "options": {
        "baseURL": "https://tiantianai.pro"
      },
      "models": {
        "claude-3-5-sonnet-20241022": {},
        "claude-opus-4-5-20251101":
      }
    }
  },
  "model": "myproxy/claude-opus-4-5-20251101"
}
```

#### 配置方式 2：OpenAI 格式（适合 GPT 模型）

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "myproxy": {
      "npm": "@ai-sdk/openai-compatible",
      "options": {
        "baseURL": "https://tiantianai.pro/v1"
      },
      "models": {
        "gpt-4o": {},
        "gpt-4-turbo": {}
      }
    }
  },
  "model": "myproxy/gpt-4o"
}
```

#### 配置方式 3：同时支持两种格式（推荐）

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "myproxy-claude": {
      "npm": "@ai-sdk/anthropic",
      "options": {
        "baseURL": "https://tiantianai.pro"
      },
      "models": {
        "claude-3-5-sonnet-20241022": {},
        "claude-opus-4-5-20251101": {}
      }
    },
    "myproxy-openai": {
      "npm": "@ai-sdk/openai-compatible",
      "options": {
        "baseURL": "https://tiantianai.pro/v1"
      },
      "models": {
        "gpt-4o": {},
        "gpt-4-turbo": {}
      }
    }
  },
  "model": "myproxy-claude/claude-opus-4-5-20251101"
}
```

**步骤 3：设置 OPENCODE_CONFIG 环境变量**

⚠️ **这一步是 Windows 能用的关键！**

按 `Win + R`，输入 `sysdm.cpl`：

1. 点击「高级」→「环境变量」
2. 在「用户变量」中点「新建」
3. 变量名：`OPENCODE_CONFIG`
4. 变量值：`C:\Users\<你的用户名>\.opencode.json`
5. 点确定，**重启 PowerShell**

**步骤 4：保存 API 密钥**

```powershell
opencode auth login
```

根据配置方式：
- **方式 1 或 2**：Provider ID 输入 `myproxy`
- **方式 3**：需要分别登录 `myproxy-claude` 和 `myproxy-openai`

**步骤 5：验证**

```powershell
opencode models
```

---

## 🎯 高级配置

### 1. 创建启动脚本

创建 `opencode-start.ps1`：

```powershell
# OpenCode 启动脚本
$env:ANTHROPIC_BASE_URL = "https://tiantianai.pro/v1"
$env:ANTHROPIC_API_KEY = "your-api-key"

Write-Host "OpenCode 已配置" -ForegroundColor Green
Write-Host "  Base URL: $env:ANTHROPIC_BASE_URL" -ForegroundColor Cyan
Write-Host "  API Key: $($env:ANTHROPIC_API_KEY.Substring(0,20))..." -ForegroundColor Cyan
Write-Host ""

# 如果没有指定模型，使用默认模型
if ($args -notcontains "-m" -and $args -notcontains "--model") {
    Write-Host "使用默认模型: claude-opus-4-5-20251101" -ForegroundColor Yellow
    opencode -m anthropic/claude-opus-4-5-20251101 $args
} else {
    opencode $args
}
```

**使用方法**：

```powershell
# 允许执行脚本（首次需要）
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# 运行脚本
powershell -File .\opencode-start.ps1
```

### 2. 创建 PowerShell 函数

编辑 PowerShell 配置文件：

```powershell
notepad $PROFILE
```

添加以下内容：

```powershell
# OpenCode 快捷函数
function oc {
    $env:ANTHROPIC_BASE_URL = "https://tiantianai.pro/v1"
    $env:ANTHROPIC_API_KEY = "your-api-key"
    opencode $args
}

function oc-opus {
    $env:ANTHROPIC_BASE_URL = "https://tiantianai.pro/v1"
    $env:ANTHROPIC_API_KEY = "your-api-key"
    opencode -m anthropic/claude-opus-4-5-20251101 $args
}

function oc-sonnet {
    $env:ANTHROPIC_BASE_URL = "https://tiantianai.pro/v1"
    $env:ANTHROPIC_API_KEY = "your-api-key"
    opencode -m anthropic/claude-sonnet-4-5 $args
}

# 显示配置信息
Write-Host "OpenCode 快捷命令已加载:" -ForegroundColor Green
Write-Host "  oc        - 启动 OpenCode" -ForegroundColor Gray
Write-Host "  oc-opus   - 使用 Opus 4.5" -ForegroundColor Gray
Write-Host "  oc-sonnet - 使用 Sonnet 4.5" -ForegroundColor Gray
```

保存后，重启 PowerShell，就可以使用：

```powershell
oc          # 启动 OpenCode
oc-opus     # 使用 Opus 4.5
oc-sonnet   # 使用 Sonnet 4.5
```

### 3. 创建批处理文件

创建 `opencode.bat`：

```batch
@echo off
set ANTHROPIC_BASE_URL=https://tiantianai.pro/v1
set ANTHROPIC_API_KEY=your-api-key

echo OpenCode 已配置
echo Base URL: %ANTHROPIC_BASE_URL%
echo.

opencode %*
```

双击运行或在 CMD 中调用。

### 4. 创建桌面快捷方式

**步骤 1：创建启动脚本**

创建 `C:\Users\<你的用户名>\opencode-start.bat`：

```batch
@echo off
set ANTHROPIC_BASE_URL=https://tiantianai.pro/v1
set ANTHROPIC_API_KEY=your-api-key

echo 已配置自定义 API
echo Base URL: %ANTHROPIC_BASE_URL%
echo.
echo 启动 OpenCode...
echo.

cd /d "%USERPROFILE%"
opencode -m anthropic/claude-opus-4-5-20251101

pause
```

**步骤 2：创建快捷方式**

1. 右键桌面 → 新建 → 快捷方式
2. 位置：`C:\Windows\System32\cmd.exe /k "C:\Users\<你的用户名>\opencode-start.bat"`
3. 名称：`OpenCode`
4. 完成

现在双击桌面图标就可以启动！

### 5. Windows Terminal 配置

在 Windows Terminal 的 `settings.json` 中添加：

```json
{
    "profiles": {
        "list": [
            {
                "name": "OpenCode",
                "commandline": "powershell.exe -NoExit -Command \"$env:ANTHROPIC_BASE_URL='https://tiantianai.pro/v1'; $env:ANTHROPIC_API_KEY='your-key'; opencode\"",
                "icon": "🤖",
                "startingDirectory": "%USERPROFILE%",
                "colorScheme": "One Half Dark"
            }
        ]
    }
}
```

### 6. 右键菜单集成

创建 `add-opencode-context-menu.reg`：

```reg
Windows Registry Editor Version 5.00

[HKEY_CLASSES_ROOT\Directory\Background\shell\OpenCode]
@="在此处打开 OpenCode"
"Icon"="C:\\Windows\\System32\\cmd.exe"

[HKEY_CLASSES_ROOT\Directory\Background\shell\OpenCode\command]
@="powershell.exe -NoExit -Command \"$env:ANTHROPIC_BASE_URL='https://tiantianai.pro/v1'; $env:ANTHROPIC_API_KEY='your-key'; Set-Location '%V'; opencode\""
```

双击运行，然后在任意文件夹右键就能看到"在此处打开 OpenCode"。

---

## ❓ 常见问题

### Q1: 环境变量设置后不生效？

**解决方法**：

1. **确认已重启 PowerShell**
   - 设置环境变量后必须重启终端

2. **检查环境变量是否设置成功**
   ```powershell
   echo $env:ANTHROPIC_BASE_URL
   echo $env:ANTHROPIC_API_KEY
   ```

3. **检查是否设置在用户变量中**
   - 按 `Win + R`，输入 `sysdm.cpl`
   - 确认变量在「用户变量」区域

4. **尝试注销并重新登录 Windows**

### Q2: PowerShell 脚本无法执行？

**错误信息**：`无法加载文件，因为在此系统上禁止运行脚本`

**解决方法**：

```powershell
# 检查执行策略
Get-ExecutionPolicy

# 修改执行策略
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Q3: 如何验证 API 是否可用？

```powershell
# 测试 API 连接
$headers = @{
    "Content-Type" = "application/json"
    "x-api-key" = $env:ANTHROPIC_API_KEY
}
$body = @{
    model = "claude-opus-4-5-20251101"
    max_tokens = 100
    messages = @(@{
        role = "user"
        content = "Hello"
    })
} | ConvertTo-Json

Invoke-RestMethod -Uri "$env:ANTHROPIC_BASE_URL/messages" -Method Post -Headers $headers -Body $body
```

### Q4: 配置文件方式不生效？

**检查清单**：

1. ✅ 确认已设置 `OPENCODE_CONFIG` 环境变量
2. ✅ 确认配置文件路径正确
3. ✅ 确认 JSON 格式正确
4. ✅ 确认已运行 `opencode auth login`
5. ✅ 确认 Provider ID 与配置文件一致

### Q5: 如何快速切换不同的 API？

**方法 1：使用 PowerShell 函数**

在 `$PROFILE` 中添加：

```powershell
function oc-api1 {
    $env:ANTHROPIC_BASE_URL = "https://api1.com/v1"
    $env:ANTHROPIC_API_KEY = "key1"
    opencode $args
}

function oc-api2 {
    $env:ANTHROPIC_BASE_URL = "https://api2.com/v1"
    $env:ANTHROPIC_API_KEY = "key2"
    opencode $args
}
```

**方法 2：使用不同的批处理文件**

创建多个 `.bat` 文件，每个配置不同的 API。

### Q6: Git Bash 中环境变量不生效？

Git Bash 使用的是 Unix 风格的环境变量，需要单独配置：

```bash
# 在 ~/.bashrc 中添加
export ANTHROPIC_BASE_URL="https://tiantianai.pro/v1"
export ANTHROPIC_API_KEY="your-api-key"
```

**推荐**：在 Windows 上使用 PowerShell 或 CMD，不要使用 Git Bash。

### Q7: 如何查看 PowerShell 配置文件位置？

```powershell
# 查看配置文件路径
echo $PROFILE

# 如果文件不存在，创建它
if (!(Test-Path $PROFILE)) {
    New-Item -Path $PROFILE -ItemType File -Force
}

# 编辑配置文件
notepad $PROFILE
```

### Q8: 环境变量和配置文件哪个优先级更高？

**优先级顺序**（从高到低）：

1. 当前会话环境变量（`$env:ANTHROPIC_API_KEY = "..."`）
2. 用户级环境变量（系统设置）
3. 配置文件（`.opencode.json`）

**推荐**：日常使用环境变量，复杂场景使用配置文件。

---

## 💡 实用技巧

### 技巧 1：自动显示配置信息

在 PowerShell 配置文件（`$PROFILE`）中添加：

```powershell
if ($env:ANTHROPIC_BASE_URL) {
    Write-Host "OpenCode 环境变量已配置:" -ForegroundColor Green
    Write-Host "  Base URL: $env:ANTHROPIC_BASE_URL" -ForegroundColor Cyan
    Write-Host "  API Key: $($env:ANTHROPIC_API_KEY.Substring(0,20))..." -ForegroundColor Cyan
}
```

### 技巧 2：创建项目专用配置

在项目目录创建 `.env.ps1`：

```powershell
# 项目专用 API 配置
$env:ANTHROPIC_BASE_URL = "https://project-api.com/v1"
$env:ANTHROPIC_API_KEY = "project-key"
```

使用：

```powershell
# 加载项目配置并启动
. .\.env.ps1; opencode
```

### 技巧 3：使用别名简化命令

```powershell
# 在 $PROFILE 中添加
Set-Alias oc opencode
```

然后就可以使用 `oc` 代替 `opencode`。

### 技巧 4：批量测试多个 API

创建 `test-apis.ps1`：

```powershell
$apis = @(
    @{ Name = "API 1"; URL = "https://api1.com/v1"; Key = "key1" },
    @{ Name = "API 2"; URL = "https://api2.com/v1"; Key = "key2" },
    @{ Name = "API 3"; URL = "https://api3.com/v1"; Key = "key3" }
)

foreach ($api in $apis) {
    Write-Host "测试 $($api.Name)..." -ForegroundColor Yellow
    $env:ANTHROPIC_BASE_URL = $api.URL
    $env:ANTHROPIC_API_KEY = $api.Key

    try {
        opencode models | Select-Object -First 5
        Write-Host "✓ $($api.Name) 可用" -ForegroundColor Green
    } catch {
        Write-Host "✗ $($api.Name) 不可用" -ForegroundColor Red
    }
    Write-Host ""
}
```

### 技巧 5：记录使用日志

创建带日志的启动脚本：

```powershell
$logFile = "$HOME\opencode-usage.log"
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

"[$timestamp] Starting OpenCode with API: $env:ANTHROPIC_BASE_URL" | Out-File -Append $logFile

opencode $args

"[$timestamp] OpenCode session ended" | Out-File -Append $logFile
```

---

## 📚 参考资源

- **OpenCode 官方文档**: https://opencode.ai/docs
- **GitHub 仓库**: https://github.com/anomalyco/opencode
- **问题反馈**: https://github.com/anomalyco/opencode/issues

---

## 🎉 总结

### 推荐配置方式

**新手用户**：
1. 使用图形界面设置环境变量
2. 3 分钟完成配置
3. 无需编写代码

**高级用户**：
1. 使用 PowerShell 命令设置
2. 创建启动脚本
3. 配置 PowerShell 函数

**企业用户**：
1. 使用配置文件方式
2. 支持多个 provider
3. 便于团队管理

### 配置检查清单

- [ ] 环境变量已设置
- [ ] PowerShell 已重启
- [ ] 环境变量验证成功
- [ ] `opencode models` 显示模型列表
- [ ] OpenCode 可以正常启动

### 下一步

配置完成后，你可以：

1. 启动 OpenCode：`opencode`
2. 指定模型：`opencode -m anthropic/claude-opus-4-5-20251101`
3. 查看帮助：`opencode --help`
4. 查看模型：`opencode models`

---

**最后更新**: 2026-01-28
**文档版本**: 2.0
