# OpenCode Windows 配置工具包

这个工具包包含了 Windows 用户配置 OpenCode 所需的所有脚本和文档。

## 📦 文件清单

### 📄 文档文件

1. **OpenCode-Windows配置完全指南.md**
   - Windows 用户的完整配置指南
   - 包含详细的步骤说明和截图指引
   - 涵盖所有配置方式和常见问题

2. **OpenCode安装教程.md**
   - 跨平台安装教程（Windows/macOS/Linux）
   - 包含环境变量和配置文件两种方式
   - 详细的常见问题解答

3. **opencode-使用指南.md**
   - OpenCode 使用指南
   - 模型切换方法
   - 高级使用技巧

### 🔧 配置脚本

4. **setup-opencode-windows.ps1**
   - 一键配置脚本（PowerShell 版本）
   - 交互式配置环境变量
   - 自动验证配置

5. **opencode-start-windows.ps1**
   - OpenCode 启动脚本（PowerShell 版本）
   - 自动配置环境变量并启动
   - 支持指定模型

6. **opencode-start-windows.bat**
   - OpenCode 启动脚本（批处理版本）
   - 双击即可运行
   - 适合不熟悉 PowerShell 的用户

### 🖱️ 右键菜单

7. **add-opencode-context-menu.reg**
   - 添加右键菜单"在此处打开 OpenCode"
   - 双击导入注册表即可

8. **remove-opencode-context-menu.reg**
   - 删除右键菜单
   - 双击导入注册表即可

## 🚀 快速开始

### 方式 1：一键配置（推荐新手）

1. 右键 `setup-opencode-windows.ps1`
2. 选择「使用 PowerShell 运行」
3. 按提示输入 API 信息
4. 完成！

### 方式 2：手动配置

1. 阅读 `OpenCode-Windows配置完全指南.md`
2. 按照指南设置环境变量
3. 验证配置
4. 启动 OpenCode

### 方式 3：使用启动脚本

1. 编辑 `opencode-start-windows.ps1` 或 `opencode-start-windows.bat`
2. 修改其中的 API 信息
3. 双击运行脚本
4. OpenCode 自动启动

## 📖 使用说明

### 配置环境变量

**图形界面方式**：

1. 按 `Win + R`，输入 `sysdm.cpl`
2. 点击「高级」→「环境变量」
3. 在「用户变量」中添加：
   - `ANTHROPIC_BASE_URL` = `https://tiantianai.pro/v1`
   - `ANTHROPIC_API_KEY` = `你的 API Key`
4. 重启 PowerShell

**PowerShell 命令方式**：

```powershell
# 运行一键配置脚本
.\setup-opencode-windows.ps1
```

### 启动 OpenCode

**方式 1：直接启动**

```powershell
opencode
```

**方式 2：使用启动脚本**

```powershell
# PowerShell 版本
.\opencode-start-windows.ps1

# 批处理版本（双击运行）
opencode-start-windows.bat
```

**方式 3：指定模型启动**

```powershell
opencode -m anthropic/claude-opus-4-5-20251101
```

### 添加右键菜单

1. 编辑 `add-opencode-context-menu.reg`
2. 修改其中的 API Key
3. 双击导入注册表
4. 在任意文件夹空白处右键，选择「在此处打开 OpenCode」

### 删除右键菜单

双击 `remove-opencode-context-menu.reg` 即可。

## 🎯 配置方式对比

| 特性 | 环境变量 | 配置文件 |
|------|---------|---------|
| 配置难度 | ⭐ 简单 | ⭐⭐⭐ 复杂 |
| 配置时间 | 3 分钟 | 10 分钟 |
| 需要 JSON | ❌ 不需要 | ✅ 需要 |
| 支持多 provider | ❌ 不支持 | ✅ 支持 |
| 适合新手 | ✅ 推荐 | ❌ 不推荐 |

**推荐**：新手使用环境变量方式，高级用户使用配置文件方式。

## ❓ 常见问题

### Q1: PowerShell 脚本无法执行？

**错误信息**：`无法加载文件，因为在此系统上禁止运行脚本`

**解决方法**：

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Q2: 环境变量设置后不生效？

**解决方法**：

1. 确认已重启 PowerShell
2. 检查环境变量：
   ```powershell
   echo $env:ANTHROPIC_BASE_URL
   echo $env:ANTHROPIC_API_KEY
   ```
3. 如果为空，重新设置环境变量

### Q3: 如何验证配置是否成功？

```powershell
# 查看可用模型
opencode models

# 如果看到 anthropic/ 开头的模型，说明配置成功
```

### Q4: 如何切换不同的模型？

```powershell
# 方式 1：启动时指定
opencode -m anthropic/claude-opus-4-5-20251101

# 方式 2：在界面中切换
# 启动后按 / 键，输入 model，选择模型
```

### Q5: 如何快速切换不同的 API？

创建多个启动脚本，每个配置不同的 API：

```powershell
# opencode-api1.ps1
$env:ANTHROPIC_BASE_URL = "https://api1.com/v1"
$env:ANTHROPIC_API_KEY = "key1"
opencode $args

# opencode-api2.ps1
$env:ANTHROPIC_BASE_URL = "https://api2.com/v1"
$env:ANTHROPIC_API_KEY = "key2"
opencode $args
```

## 📚 详细文档

- **完整配置指南**：查看 `OpenCode-Windows配置完全指南.md`
- **安装教程**：查看 `OpenCode安装教程.md`
- **使用指南**：查看 `opencode-使用指南.md`

## 🔗 相关链接

- **OpenCode 官方文档**: https://opencode.ai/docs
- **GitHub 仓库**: https://github.com/anomalyco/opencode
- **问题反馈**: https://github.com/anomalyco/opencode/issues

## 📝 文件修改说明

### 需要修改的文件

在使用前，请修改以下文件中的 API 信息：

1. **opencode-start-windows.ps1**
   - 第 4 行：`$env:ANTHROPIC_BASE_URL`
   - 第 5 行：`$env:ANTHROPIC_API_KEY`

2. **opencode-start-windows.bat**
   - 第 5 行：`set ANTHROPIC_BASE_URL`
   - 第 6 行：`set ANTHROPIC_API_KEY`

3. **add-opencode-context-menu.reg**
   - 第 10 行：修改 API Key

### 不需要修改的文件

- `setup-opencode-windows.ps1`（交互式输入）
- `remove-opencode-context-menu.reg`（删除脚本）
- 所有文档文件（`.md` 文件）

## 🎉 使用建议

### 新手用户

1. 先阅读 `OpenCode-Windows配置完全指南.md`
2. 使用 `setup-opencode-windows.ps1` 一键配置
3. 使用 `opencode-start-windows.bat` 启动（双击即可）

### 高级用户

1. 手动设置环境变量
2. 创建 PowerShell 函数（在 `$PROFILE` 中）
3. 配置 Windows Terminal 快捷启动
4. 添加右键菜单集成

### 企业用户

1. 使用配置文件方式（`.opencode.json`）
2. 支持多个 provider
3. 便于团队统一管理

## 🔄 更新日志

### v2.0 (2026-01-28)

- ✅ 新增环境变量配置方式（推荐）
- ✅ 新增一键配置脚本
- ✅ 新增启动脚本（PowerShell 和批处理版本）
- ✅ 新增右键菜单集成
- ✅ 新增 Windows 完全配置指南
- ✅ 扩展常见问题解答（新增 9 个问题）
- ✅ 添加详细的使用技巧

### v1.0 (2026-01-27)

- 初始版本
- 基本的配置文件方式说明

## 📞 支持

如果遇到问题：

1. 查看 `OpenCode-Windows配置完全指南.md` 中的常见问题
2. 查看 `OpenCode安装教程.md` 中的故障排除
3. 在 GitHub 提交 Issue

---

**最后更新**: 2026-01-28
**工具包版本**: 2.0
**适用系统**: Windows 10/11
