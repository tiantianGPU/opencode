# OpenCode 安装教程

OpenCode 是一个开源的 AI 代码助手工具，支持多种 AI 模型提供商。本教程将指导你在不同操作系统上安装 OpenCode 并配置自定义 API。

---

## 目录
- [系统要求](#系统要求)
- [安装方法](#安装方法)
  - [macOS 安装](#macos-安装)
  - [Windows 安装](#windows-安装)
  - [Linux 安装](#linux-安装)
  - [通用安装方法](#通用安装方法)
- [桌面应用程序（BETA）](#桌面应用程序beta)
- [自定义 API 配置](#自定义-api-配置)
  - [Windows 用户配置（重要）](#windows-用户配置自定义-api重要)
  - [macOS/Linux 用户配置](#macoslinux-用户配置)
  - [支持的 AI 提供商](#支持的-ai-提供商)
- [使用说明](#使用说明)
- [常见问题](#常见问题)

---

## 系统要求

- **操作系统**: Windows、macOS、Linux
- **架构**: x64 或 ARM64 (Apple Silicon)
- **运行时**: Node.js（使用 npm 安装时需要）
- **网络**: 需要互联网连接以访问 AI API

---

## 安装方法

### macOS 安装

#### 方法 1: Homebrew（推荐）

```bash
# 推荐：从官方 tap 安装，始终保持最新
brew install anomalyco/tap/opencode

# 或使用官方 brew formula（更新频率较低）
brew install opencode
```

#### 方法 2: 一键安装脚本

```bash
curl -fsSL https://opencode.ai/install | bash
```

#### 方法 3: npm 安装

```bash
npm i -g opencode-ai@latest
# 或使用其他包管理器
yarn global add opencode-ai@latest
pnpm add -g opencode-ai@latest
bun add -g opencode-ai@latest
```

#### 方法 4: 其他包管理器

```bash
# mise
mise use -g opencode

# nix
nix run nixpkgs#opencode
```

---

### Windows 安装

#### 方法 1: Scoop（推荐）

```powershell
scoop install opencode
```

#### 方法 2: Chocolatey

```powershell
choco install opencode
```

#### 方法 3: npm 安装

```powershell
npm i -g opencode-ai@latest
```

#### 方法 4: 一键安装脚本

在 PowerShell 或 Git Bash 中运行：

```bash
curl -fsSL https://opencode.ai/install | bash
```

---

### Linux 安装

#### 方法 1: 一键安装脚本（推荐）

```bash
curl -fsSL https://opencode.ai/install | bash
```

#### 方法 2: Homebrew

```bash
brew install anomalyco/tap/opencode
```

#### 方法 3: Arch Linux (AUR)

```bash
paru -S opencode-bin
# 或使用 yay
yay -S opencode-bin
```

#### 方法 4: npm 安装

```bash
npm i -g opencode-ai@latest
```

#### 方法 5: 其他包管理器

```bash
# mise
mise use -g opencode

# nix
nix run nixpkgs#opencode
```

---

### 通用安装方法

#### 自定义安装目录

安装脚本按以下优先级决定安装路径：

1. `$OPENCODE_INSTALL_DIR` - 自定义安装目录
2. `$XDG_BIN_DIR` - 符合 XDG 基础目录规范的路径
3. `$HOME/bin` - 用户二进制目录
4. `$HOME/.opencode/bin` - 默认备用路径

**示例：指定安装目录**

```bash
# 安装到 /usr/local/bin
OPENCODE_INSTALL_DIR=/usr/local/bin curl -fsSL https://opencode.ai/install | bash

# 安装到 ~/.local/bin
XDG_BIN_DIR=$HOME/.local/bin curl -fsSL https://opencode.ai/install | bash
```

---

## 桌面应用程序（BETA）

OpenCode 提供桌面版应用程序，可从以下位置下载：

- [GitHub Releases](https://github.com/anomalyco/opencode/releases)
- [opencode.ai/download](https://opencode.ai/download)

### 支持的平台

| 操作系统 | 架构 | 文件名 |
|---------|------|--------|
| macOS | Apple Silicon (M1/M2/M3) | `opencode-desktop-darwin-aarch64.dmg` |
| macOS | Intel | `opencode-desktop-darwin-x64.dmg` |
| Windows | x64 | `opencode-desktop-windows-x64.exe` |
| Linux | x64 | `.deb`、`.rpm` 或 AppImage |

### 桌面版包管理器安装

**macOS (Homebrew Cask)**

```bash
brew install --cask opencode-desktop
```

**Windows (Scoop)**

```powershell
scoop bucket add extras
scoop install extras/opencode-desktop
```

---

## 自定义 API 配置

OpenCode 支持多种 AI 模型提供商，包括 Claude、OpenAI、Google 以及本地模型。

### Windows 用户配置自定义 API（重要！）

**适用于 Windows 10/11 用户**

Windows 用户有两种配置方式，推荐使用环境变量方式（更简单）：

---

#### 🌟 方法 1：使用环境变量（推荐，最简单）

**适用场景**：使用 Anthropic 官方 API 或兼容 Anthropic API 格式的中转服务

**优点**：
- ✅ 无需创建 JSON 配置文件
- ✅ 无需运行 `opencode auth login`
- ✅ 配置简单，3 步完成
- ✅ 适合大多数用户

##### 步骤 1：设置环境变量（永久生效）

**方法 A：使用图形界面（推荐新手）**

1. 按 `Win + R`，输入 `sysdm.cpl`，回车
2. 点击「高级」选项卡
3. 点击「环境变量」按钮
4. 在「用户变量」区域点击「新建」

添加第一个变量：
- 变量名：`ANTHROPIC_BASE_URL`
- 变量值：`https://tiantianai.pro/v1`
- 点击「确定」

再次点击「新建」，添加第二个变量：
- 变量名：`ANTHROPIC_API_KEY`
- 变量值：`sk-NFnWE5NQfs2tcGuVeIIVsSNA7LZMLcBGzV4HVJFioiWn3O0c`（替换为你的 API Key）
- 点击「确定」

5. 点击「确定」关闭所有对话框
6. **重启 PowerShell 或 CMD**（重要！）

**方法 B：使用 PowerShell 命令（推荐高级用户）**

以管理员身份运行 PowerShell，执行：

```powershell
# 设置用户级环境变量（永久生效）
[System.Environment]::SetEnvironmentVariable('ANTHROPIC_BASE_URL', 'https://tiantianai.pro/v1', 'User')
[System.Environment]::SetEnvironmentVariable('ANTHROPIC_API_KEY', 'sk-NFnWE5NQfs2tcGuVeIIVsSNA7LZMLcBGzV4HVJFioiWn3O0c', 'User')

# 验证设置
[System.Environment]::GetEnvironmentVariable('ANTHROPIC_BASE_URL', 'User')
[System.Environment]::GetEnvironmentVariable('ANTHROPIC_API_KEY', 'User')
```

**重启 PowerShell** 使环境变量生效。

##### 步骤 2：验证配置

打开新的 PowerShell 窗口，执行：

```powershell
# 检查环境变量
echo $env:ANTHROPIC_BASE_URL
echo $env:ANTHROPIC_API_KEY

# 查看可用模型
opencode models
```

如果看到 `anthropic/` 开头的模型列表，说明配置成功！

##### 步骤 3：启动 OpenCode

```powershell
# 直接启动
opencode

# 或指定模型启动
opencode -m anthropic/claude-opus-4-5-20251101
```

##### 临时使用（不永久配置）

如果只想临时测试，可以在当前 PowerShell 会话中设置：

```powershell
# 仅在当前 PowerShell 会话生效
$env:ANTHROPIC_BASE_URL = "https://tiantianai.pro/v1"
$env:ANTHROPIC_API_KEY = "sk-NFnWE5NQfs2tcGuVeIIVsSNA7LZMLcBGzV4HVJFioiWn3O0c"

# 启动 OpenCode
opencode
```

##### 创建启动脚本（推荐）

创建一个 PowerShell 脚本文件 `opencode-start.ps1`：

```powershell
# 在你的用户目录创建脚本
notepad $HOME\opencode-start.ps1
```

在记事本中输入以下内容：

```powershell
# OpenCode 启动脚本
$env:ANTHROPIC_BASE_URL = "https://tiantianai.pro/v1"
$env:ANTHROPIC_API_KEY = "sk-NFnWE5NQfs2tcGuVeIIVsSNA7LZMLcBGzV4HVJFioiWn3O0c"

Write-Host "已配置自定义 API:" -ForegroundColor Green
Write-Host "  Base URL: $env:ANTHROPIC_BASE_URL" -ForegroundColor Cyan
Write-Host "  API Key: $($env:ANTHROPIC_API_KEY.Substring(0,20))..." -ForegroundColor Cyan
Write-Host ""

# 如果没有指定模型，使用默认模型
if ($args -notcontains "-m" -and $args -notcontains "--model") {
    Write-Host "使用默认模型: claude-opus-4-5-20251101" -ForegroundColor Yellow
    opencode -m anthropic/claude-opus-4-5-20251101 $args
} else {
    Write-Host "启动 OpenCode..." -ForegroundColor Yellow
    opencode $args
}
```

保存后，使用方式：

```powershell
# 允许执行脚本（首次需要）
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# 使用脚本启动
powershell -File $HOME\opencode-start.ps1

# 或创建别名（添加到 PowerShell 配置文件）
notepad $PROFILE
# 在文件中添加：
# function oc { & "$HOME\opencode-start.ps1" $args }

# 然后就可以直接使用
oc
```

---

#### 📋 方法 2：使用配置文件（适合复杂场景）

**适用场景**：
- 需要同时配置多个 provider（OpenAI + Claude）
- 需要使用 OpenAI 格式的 API
- 需要更灵活的模型配置

**第 1 步：创建配置文件**

在你的用户目录下新建文件：
```
C:\Users\<你的用户名>\.opencode.json
```

💡 **提示**：
- 把 `<你的用户名>` 换成你自己的，比如 `C:\Users\Administrator\.opencode.json`
- 可直接在文件资源管理器地址栏输入 `.opencode.json` 回车创建

填入以下内容（根据需要选择配置方式）：

**配置方式 1：使用 OpenAI 格式（适合 GPT 模型）**

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "myproxy": {
      "npm": "@ai-sdk/openai-compatible",
      "options": {
        "baseURL": "https://tiantianai.pro/v1"
      },
      "models": {
        "gpt-4o": {},
        "gpt-4-turbo": {}
      }
    }
  },
  "model": "myproxy/gpt-4o"
}
```

**配置方式 2：使用 Claude 格式（适合 Claude 模型）**

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "myproxy": {
      "npm": "@ai-sdk/anthropic",
      "options": {
        "baseURL": "https://tiantianai.pro"
      },
      "models": {
        "claude-3-5-sonnet-20241022": {},
        "claude-opus-4-5-20251101": {}
      }
    }
  },
  "model": "myproxy/claude-3-5-sonnet-20241022"
}
```

**配置方式 3：同时支持两种格式（推荐）**

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "myproxy-openai": {
      "npm": "@ai-sdk/openai-compatible",
      "options": {
        "baseURL": "https://tiantianai.pro/v1"
      },
      "models": {
        "gpt-4o": {},
        "gpt-4-turbo": {}
      }
    },
    "myproxy-claude": {
      "npm": "@ai-sdk/anthropic",
      "options": {
        "baseURL": "https://tiantianai.pro"
      },
      "models": {
        "claude-3-5-sonnet-20241022": {},
        "claude-opus-4-5-20251101": {}
      }
    }
  },
  "model": "myproxy-claude/claude-3-5-sonnet-20241022"
}
```

**第 2 步：设置环境变量（Windows 关键！）**

⚠️ **这一步是 Windows 能用的关键！Linux/macOS 不需要。**

OpenCode 不会自动读取上面的文件，必须手动指定路径：

1. 按 `Win + R`，输入 `sysdm.cpl`，回车
2. 点击「高级」→「环境变量」
3. 在「用户变量」中点「新建」
4. 变量名：`OPENCODE_CONFIG`
5. 变量值：`C:\Users\<你的用户名>\.opencode.json`
6. 点确定，**重启 PowerShell 或 CMD**

**第 3 步：保存 API 密钥**

在 PowerShell 中运行：

```powershell
opencode auth login
```

根据你选择的配置方式：

- **方式 1 或 2**：Provider ID 输入 `myproxy`（必须和 JSON 里的一致）
- **方式 3**：需要分别登录两个 provider
  - 先输入 Provider ID: `myproxy-openai`，选择 `Other`，输入 API Key
  - 再次运行 `opencode auth login`
  - 输入 Provider ID: `myproxy-claude`，输入 API Key

💡 **提示**：
- 如果使用 Claude 格式（方式 2），直接输入 API Key 即可
- 如果使用 OpenAI 格式（方式 1），选择 `Other` 后输入 API Key
- 密钥会自动保存，无需写进 JSON

**第 4 步：验证**

```powershell
opencode
```

进入界面后输入：
```
/models
```

如果看到你配置的模型（如 `gpt-4o`），说明成功！

#### ❌ 常见失败原因

- 忘了设 `OPENCODE_CONFIG` 环境变量 → 配置文件不加载
- Provider ID 前后不一致（JSON 里是 `myproxy`，登录时却输 `proxy`）
- `baseURL` 写错（必须是 `.../v1`，不能带 `/chat/completions`）

---

### macOS/Linux 用户配置

#### 方法 1: 使用环境变量（推荐，最简单）

**适用场景**：使用 Anthropic 官方 API 或兼容 Anthropic API 格式的中转服务

**配置步骤**：

1. 创建环境变量配置文件：

```bash
cat > ~/.opencode_env << 'EOF'
# OpenCode 自定义 API 配置
export ANTHROPIC_BASE_URL="https://tiantianai.pro/v1"
export ANTHROPIC_API_KEY="your-api-key-here"
EOF
```

2. 将配置添加到 shell 配置文件（永久生效）：

```bash
# 如果使用 zsh（macOS 默认）
echo 'source ~/.opencode_env' >> ~/.zshrc
source ~/.zshrc

# 如果使用 bash
echo 'source ~/.opencode_env' >> ~/.bashrc
source ~/.bashrc
```

3. 验证配置：

```bash
echo $ANTHROPIC_BASE_URL
echo $ANTHROPIC_API_KEY
```

4. 启动 OpenCode：

```bash
opencode
```

**临时使用（不永久配置）**：

```bash
# 仅在当前终端会话生效
source ~/.opencode_env && opencode
```

**使用启动脚本**：

创建一个便捷的启动脚本：

```bash
cat > ~/opencode-start.sh << 'EOF'
#!/bin/bash
export ANTHROPIC_BASE_URL="https://tiantianai.pro/v1"
export ANTHROPIC_API_KEY="your-api-key-here"

# 如果没有指定模型，使用默认模型
if [[ "$*" != *"-m"* ]] && [[ "$*" != *"--model"* ]]; then
    echo "使用默认模型: claude-opus-4-5-20251101"
    opencode -m anthropic/claude-opus-4-5-20251101 "$@"
else
    opencode "$@"
fi
EOF

chmod +x ~/opencode-start.sh

# 使用方式
~/opencode-start.sh
```

**优点**：
- ✅ 配置简单，无需编写 JSON
- ✅ 适合 Anthropic API 格式的服务
- ✅ 可以快速切换不同的 API 端点
- ✅ 不需要运行 `opencode auth login`

**注意事项**：
- 环境变量方法仅支持 Anthropic API 格式
- 如需使用 OpenAI 格式或多个 provider，请使用方法 2（配置文件）

---

#### 方法 2: 使用配置文件

**配置文件位置**：
- **macOS/Linux**: `~/.opencode.json` 或 `~/.config/opencode/config.json`

**使用 Claude API**

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "anthropic": {
      "npm": "@ai-sdk/anthropic",
      "models": {
        "claude-3-5-sonnet-20241022": {},
        "claude-opus-4-5-20251101": {}
      }
    }
  },
  "model": "anthropic/claude-3-5-sonnet-20241022"
}
```

然后运行：
```bash
opencode auth login
```
- Provider ID: `anthropic`
- 输入 API Key（从 [console.anthropic.com](https://console.anthropic.com/) 获取）

**使用 OpenAI API**

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "openai": {
      "npm": "@ai-sdk/openai",
      "models": {
        "gpt-4o": {},
        "gpt-4-turbo": {}
      }
    }
  },
  "model": "openai/gpt-4o"
}
```

然后运行：
```bash
opencode auth login
```
- Provider ID: `openai`
- 输入 API Key（从 [platform.openai.com](https://platform.openai.com/) 获取）

**使用自定义 API 端点（中转 API）**

方式 1：使用 OpenAI 兼容格式（推荐用于 GPT 模型）

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "myproxy": {
      "npm": "@ai-sdk/openai-compatible",
      "options": {
        "baseURL": "https://tiantianai.pro/v1"
      },
      "models": {
        "gpt-4o": {},
        "gpt-4-turbo": {}
      }
    }
  },
  "model": "myproxy/gpt-4o"
}
```

然后运行：
```bash
opencode auth login
```
- Provider ID: `myproxy`
- 选择 `Other`
- 输入你的 API Key

方式 2：使用 Claude 原生格式（推荐用于 Claude 模型）

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "myproxy-claude": {
      "npm": "@ai-sdk/anthropic",
      "options": {
        "baseURL": "https://tiantianai.pro"
      },
      "models": {
        "claude-3-5-sonnet-20241022": {},
        "claude-opus-4-5-20251101": {}
      }
    }
  },
  "model": "myproxy-claude/claude-3-5-sonnet-20241022"
}
```

然后运行：
```bash
opencode auth login
```
- Provider ID: `myproxy-claude`
- 输入你的 API Key

方式 3：同时配置两种格式（可以使用所有模型）

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "myproxy": {
      "npm": "@ai-sdk/openai-compatible",
      "options": {
        "baseURL": "https://tiantianai.pro/v1"
      },
      "models": {
        "gpt-4o": {},
        "gpt-4-turbo": {}
      }
    },
    "myproxy-claude": {
      "npm": "@ai-sdk/anthropic",
      "options": {
        "baseURL": "https://tiantianai.pro"
      },
      "models": {
        "claude-3-5-sonnet-20241022": {},
        "claude-opus-4-5-20251101": {}
      }
    }
  },
  "model": "myproxy-claude/claude-3-5-sonnet-20241022"
}
```

然后分别为两个 provider 登录：
```bash
opencode auth login
```
- 先输入 Provider ID: `myproxy`，选择 `Other`，输入 API Key
- 再次运行 `opencode auth login`
- 输入 Provider ID: `myproxy-claude`，输入 API Key

**使用本地模型（Ollama）**

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "ollama": {
      "npm": "@ai-sdk/openai-compatible",
      "options": {
        "baseURL": "http://localhost:11434/v1"
      },
      "models": {
        "codellama": {},
        "deepseek-coder": {}
      }
    }
  },
  "model": "ollama/codellama"
}
```

然后运行：
```bash
opencode auth login
```
- Provider ID: `ollama`
- 选择 `Other`
- API Key 可以随意填写（本地模型不需要）

#### 方法 3: 使用环境变量（传统方式）

你也可以通过环境变量配置 API：

```bash
# Claude
export ANTHROPIC_API_KEY="sk-ant-api03-your-api-key-here"
export ANTHROPIC_BASE_URL="https://tiantianai.pro/v1"

# OpenAI
export OPENAI_API_KEY="sk-your-openai-api-key-here"
export OPENAI_BASE_URL="https://your-custom-endpoint.com/v1"
```

将以上内容添加到 `~/.bashrc` 或 `~/.zshrc` 中，然后运行：
```bash
source ~/.bashrc  # 或 source ~/.zshrc
```

**注意**：此方法与方法 1 类似，但需要手动编辑 shell 配置文件。推荐使用方法 1 的自动化脚本。

---

### 支持的 AI 提供商

| 提供商 | npm 包 | 获取 API Key | 推荐模型 |
|--------|--------|-------------|---------|
| Claude (Anthropic) | `@ai-sdk/anthropic` | [console.anthropic.com](https://console.anthropic.com/) | `claude-3-5-sonnet-20241022`<br>`claude-opus-4-5-20251101` |
| OpenAI | `@ai-sdk/openai` | [platform.openai.com](https://platform.openai.com/) | `gpt-4o`<br>`gpt-4-turbo` |
| Google Gemini | `@ai-sdk/google` | [ai.google.dev](https://ai.google.dev/) | `gemini-pro`<br>`gemini-1.5-pro` |
| 自定义端点 | `@ai-sdk/openai-compatible` | 根据提供商 | 根据提供商 |
| 本地模型 (Ollama) | `@ai-sdk/openai-compatible` | 不需要 | `codellama`<br>`deepseek-coder` |

---

## 使用说明

### 启动 OpenCode

**基本启动**：
```bash
opencode
```

**指定模型启动**：
```bash
# 使用 Claude Opus 4.5
opencode -m anthropic/claude-opus-4-5-20251101

# 使用 Claude Sonnet 4.5
opencode -m anthropic/claude-sonnet-4-5

# 使用自定义 provider 的模型
opencode -m myproxy/gpt-4o
```

**在指定目录启动**：
```bash
opencode /path/to/project
```

**继续上次会话**：
```bash
opencode -c
```

**查看可用模型**：
```bash
opencode models
```

### 模型切换

OpenCode 支持多种方式切换模型：

#### 方法 1: 启动时指定模型（推荐）

```bash
# 启动时直接指定模型
opencode -m anthropic/claude-opus-4-5-20251101

# 或使用短参数
opencode -m anthropic/claude-sonnet-4-5
```

#### 方法 2: 在 TUI 界面中切换

1. 启动 opencode 后，按 `/` 键打开命令面板
2. 输入 `model` 或直接输入 `/model`
3. 从列表中选择你想要的模型
4. 按回车确认

#### 方法 3: 使用配置文件设置默认模型

在 `~/.opencode.json` 中设置：

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "myproxy": {
      "npm": "@ai-sdk/anthropic",
      "options": {
        "baseURL": "https://tiantianai.pro"
      },
      "models": {
        "claude-opus-4-5-20251101": {},
        "claude-sonnet-4-5": {}
      }
    }
  },
  "model": "myproxy/claude-opus-4-5-20251101"
}
```

`"model"` 字段指定的就是默认模型。

#### 方法 4: 创建快捷别名

在 `~/.zshrc` 或 `~/.bashrc` 中添加：

```bash
# OpenCode 快捷别名
alias oc='opencode'
alias oc-opus='opencode -m anthropic/claude-opus-4-5-20251101'
alias oc-sonnet='opencode -m anthropic/claude-sonnet-4-5'
alias oc-haiku='opencode -m anthropic/claude-haiku-4-5'
```

然后就可以使用：
```bash
oc-opus    # 使用 Opus 4.5
oc-sonnet  # 使用 Sonnet 4.5
oc-haiku   # 使用 Haiku 4.5
```

### Agent 模式

OpenCode 内置两种 Agent 模式，可用 `Tab` 键快速切换：

- **build** - 默认模式
  - 具备完整权限
  - 可以修改文件、运行命令
  - 适合开发工作

- **plan** - 只读模式
  - 默认拒绝修改文件
  - 运行 bash 命令前会询问
  - 适合代码分析与探索

### 调用子 Agent

在消息中输入 `@general` 可调用通用子 Agent，用于复杂搜索和多步任务。

### 基本命令

```bash
# 在当前目录启动
opencode

# 在指定目录启动
opencode /path/to/project

# 查看帮助
opencode --help

# 查看版本
opencode --version
```

---

## 常见问题

### 1. 安装后找不到 opencode 命令

**解决方法**：

- 确保安装目录在 PATH 中
- 重新加载 shell 配置：`source ~/.bashrc` 或 `source ~/.zshrc`
- 检查安装位置：`which opencode`（Linux/macOS）或 `where opencode`（Windows）

### 2. Windows 下配置不生效

**症状**：配置了环境变量或 `.opencode.json` 但 OpenCode 无法识别

**解决方法**：

#### 如果使用环境变量方式：

1. **确认环境变量已设置**
   ```powershell
   # 检查环境变量
   echo $env:ANTHROPIC_BASE_URL
   echo $env:ANTHROPIC_API_KEY
   ```

   如果输出为空，说明环境变量未设置成功。

2. **重启 PowerShell 或 CMD**

   设置环境变量后必须重启终端才能生效。

3. **检查环境变量是否在用户变量中**

   按 `Win + R`，输入 `sysdm.cpl`，检查「用户变量」区域是否有这两个变量。

4. **验证 API 是否可用**
   ```powershell
   # 测试 API 连接
   $headers = @{
       "Content-Type" = "application/json"
       "x-api-key" = $env:ANTHROPIC_API_KEY
   }
   $body = @{
       model = "claude-opus-4-5-20251101"
       max_tokens = 100
       messages = @(@{
           role = "user"
           content = "Hello"
       })
   } | ConvertTo-Json

   Invoke-RestMethod -Uri "$env:ANTHROPIC_BASE_URL/messages" -Method Post -Headers $headers -Body $body
   ```

#### 如果使用配置文件方式：

1. **确认已设置 `OPENCODE_CONFIG` 环境变量**
   ```powershell
   # 检查环境变量
   echo $env:OPENCODE_CONFIG
   ```

2. **如果没有输出，按照以下步骤设置**：
   - 按 `Win + R`，输入 `sysdm.cpl`，回车
   - 点击「高级」→「环境变量」
   - 在「用户变量」中点「新建」
   - 变量名：`OPENCODE_CONFIG`
   - 变量值：`C:\Users\<你的用户名>\.opencode.json`
   - 点确定，**重启 PowerShell 或 CMD**

3. **验证配置文件路径正确**：
   ```powershell
   Test-Path $env:OPENCODE_CONFIG
   ```
   应该返回 `True`

4. **检查 JSON 格式是否正确**：
   ```powershell
   # 读取并验证 JSON
   Get-Content $env:OPENCODE_CONFIG | ConvertFrom-Json
   ```
   如果报错，说明 JSON 格式有问题。

### 3. Provider ID 不匹配错误

**症状**：运行 `opencode auth login` 时提示找不到 provider

**解决方法**：

- 确保 Provider ID 与配置文件中的名称完全一致
- 例如：配置文件中是 `"myproxy"`，登录时也必须输入 `myproxy`
- 区分大小写

### 4. baseURL 配置错误

**症状**：API 调用失败，提示 404 或路径错误

**解决方法**：

- `baseURL` 必须以 `/v1` 结尾
- ✅ 正确：`https://api.xxx.com/v1`
- ❌ 错误：`https://api.xxx.com/v1/chat/completions`
- ❌ 错误：`https://api.xxx.com`

### 5. 如何更新 OpenCode？

**Homebrew**:
```bash
brew upgrade opencode
```

**npm**:
```bash
npm update -g opencode-ai
```

**Scoop**:
```powershell
scoop update opencode
```

**Chocolatey**:
```powershell
choco upgrade opencode
```

**一键安装脚本**:
```bash
curl -fsSL https://opencode.ai/install | bash
```

### 6. 如何卸载旧版本？

如果你安装了 0.1.x 之前的版本，建议先卸载：

```bash
# Homebrew
brew uninstall opencode

# npm
npm uninstall -g opencode-ai

# Scoop
scoop uninstall opencode

# Chocolatey
choco uninstall opencode

# 手动删除配置
rm -rf ~/.opencode  # Linux/macOS
rmdir /s %USERPROFILE%\.opencode  # Windows
```

### 7. API 配置不生效

**检查清单**：

- 检查配置文件格式是否正确（JSON 格式，注意逗号和引号）
- 确认 API Key 有效且有足够的配额
- 检查网络连接和防火墙设置
- 查看日志文件获取详细错误信息
- Windows 用户确认已设置 `OPENCODE_CONFIG` 环境变量

### 8. 如何查看当前配置？

在 OpenCode 界面中输入：
```
/models
```
会显示当前配置的所有可用模型。

### 9. 如何使用代理？

**Linux/macOS**:
```bash
export HTTP_PROXY=http://proxy.example.com:8080
export HTTPS_PROXY=http://proxy.example.com:8080
```

**Windows (PowerShell)**:
```powershell
$env:HTTP_PROXY="http://proxy.example.com:8080"
$env:HTTPS_PROXY="http://proxy.example.com:8080"
```

**Windows (CMD)**:
```cmd
set HTTP_PROXY=http://proxy.example.com:8080
set HTTPS_PROXY=http://proxy.example.com:8080
```

### 10. 如何切换不同的模型？

OpenCode 提供多种模型切换方式：

**方法 1：启动时指定（最简单）**

```bash
opencode -m anthropic/claude-opus-4-5-20251101
```

**方法 2：在界面中切换**

启动后按 `/` 键，输入 `model`，选择模型。

**方法 3：配置默认模型**

在配置文件中可以定义多个模型，然后在 OpenCode 中切换。

**示例 1：单个 provider 多个模型**

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "myproxy": {
      "npm": "@ai-sdk/openai-compatible",
      "options": {
        "baseURL": "https://tiantianai.pro/v1"
      },
      "models": {
        "gpt-4o": {},
        "gpt-4-turbo": {},
        "gpt-3.5-turbo": {}
      }
    }
  },
  "model": "myproxy/gpt-4o"
}
```

**示例 2：多个 provider（推荐）**

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "myproxy-openai": {
      "npm": "@ai-sdk/openai-compatible",
      "options": {
        "baseURL": "https://tiantianai.pro/v1"
      },
      "models": {
        "gpt-4o": {},
        "gpt-4-turbo": {}
      }
    },
    "myproxy-claude": {
      "npm": "@ai-sdk/anthropic",
      "options": {
        "baseURL": "https://tiantianai.pro"
      },
      "models": {
        "claude-3-5-sonnet-20241022": {},
        "claude-opus-4-5-20251101": {}
      }
    }
  },
  "model": "myproxy-claude/claude-3-5-sonnet-20241022"
}
```

在 OpenCode 界面中输入 `/model` 可以切换模型。

**方法 4：使用别名（推荐）**

在 `~/.zshrc` 或 `~/.bashrc` 中添加：

```bash
alias oc-opus='opencode -m anthropic/claude-opus-4-5-20251101'
alias oc-sonnet='opencode -m anthropic/claude-sonnet-4-5'
```

### 11. 环境变量配置和配置文件有什么区别？

**环境变量方式**：
- ✅ 配置简单，无需编写 JSON
- ✅ 适合单一 API 端点
- ✅ 不需要运行 `opencode auth login`
- ❌ 仅支持 Anthropic API 格式
- ❌ 不能同时配置多个 provider

**配置文件方式**：
- ✅ 支持多个 provider 和模型
- ✅ 支持 OpenAI、Claude、Google 等多种格式
- ✅ 配置更灵活，可以自定义模型参数
- ❌ 需要编写 JSON 配置
- ❌ 需要运行 `opencode auth login` 保存密钥

**推荐使用场景**：
- 如果只使用一个 Anthropic 兼容的 API → 使用环境变量
- 如果需要多个 provider 或 OpenAI 格式 → 使用配置文件

### 12. 如何验证环境变量配置是否生效？

```bash
# 检查环境变量
echo $ANTHROPIC_BASE_URL
echo $ANTHROPIC_API_KEY

# 查看可用模型
opencode models

# 如果看到 anthropic/ 开头的模型，说明配置成功
```

### 13. Windows 环境变量配置后重启电脑还是不生效？

**可能原因**：

1. **环境变量设置在系统变量而不是用户变量**
   - 检查：按 `Win + R`，输入 `sysdm.cpl`
   - 确认变量在「用户变量」区域，不是「系统变量」

2. **PowerShell 执行策略限制**
   ```powershell
   # 检查执行策略
   Get-ExecutionPolicy

   # 如果是 Restricted，需要修改
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   ```

3. **使用了错误的终端**
   - 确保使用的是 PowerShell 或 CMD
   - 不要使用 Git Bash（环境变量可能不同步）

4. **环境变量值包含特殊字符**
   - 确保 API Key 没有多余的空格或引号
   - 使用 PowerShell 检查：
     ```powershell
     $env:ANTHROPIC_API_KEY.Length  # 检查长度是否正确
     ```

### 14. Windows 如何快速切换不同的 API？

**方法 1：使用不同的 PowerShell 脚本**

创建多个脚本文件：

```powershell
# opencode-api1.ps1
$env:ANTHROPIC_BASE_URL = "https://api1.com/v1"
$env:ANTHROPIC_API_KEY = "key1"
opencode $args

# opencode-api2.ps1
$env:ANTHROPIC_BASE_URL = "https://api2.com/v1"
$env:ANTHROPIC_API_KEY = "key2"
opencode $args
```

使用：
```powershell
powershell -File opencode-api1.ps1
powershell -File opencode-api2.ps1
```

**方法 2：使用 PowerShell 函数**

在 PowerShell 配置文件中添加（`notepad $PROFILE`）：

```powershell
function oc-api1 {
    $env:ANTHROPIC_BASE_URL = "https://api1.com/v1"
    $env:ANTHROPIC_API_KEY = "key1"
    opencode $args
}

function oc-api2 {
    $env:ANTHROPIC_BASE_URL = "https://api2.com/v1"
    $env:ANTHROPIC_API_KEY = "key2"
    opencode $args
}

function oc-local {
    $env:ANTHROPIC_BASE_URL = "http://localhost:8000/v1"
    $env:ANTHROPIC_API_KEY = "local"
    opencode $args
}
```

使用：
```powershell
oc-api1
oc-api2
oc-local
```

**方法 3：使用批处理文件（.bat）**

创建 `opencode-api1.bat`：

```batch
@echo off
set ANTHROPIC_BASE_URL=https://api1.com/v1
set ANTHROPIC_API_KEY=key1
opencode %*
```

双击运行或在 CMD 中调用。

### 15. Windows 如何创建桌面快捷方式启动 OpenCode？

**步骤 1：创建启动脚本**

创建 `C:\Users\<你的用户名>\opencode-start.bat`：

```batch
@echo off
set ANTHROPIC_BASE_URL=https://tiantianai.pro/v1
set ANTHROPIC_API_KEY=sk-NFnWE5NQfs2tcGuVeIIVsSNA7LZMLcBGzV4HVJFioiWn3O0c

echo 已配置自定义 API
echo Base URL: %ANTHROPIC_BASE_URL%
echo.
echo 启动 OpenCode...
echo.

cd /d "%USERPROFILE%"
opencode -m anthropic/claude-opus-4-5-20251101

pause
```

**步骤 2：创建快捷方式**

1. 右键桌面 → 新建 → 快捷方式
2. 位置输入：`C:\Windows\System32\cmd.exe /k "C:\Users\<你的用户名>\opencode-start.bat"`
3. 名称输入：`OpenCode`
4. 完成

**步骤 3：自定义图标（可选）**

1. 右键快捷方式 → 属性
2. 点击「更改图标」
3. 选择喜欢的图标

现在双击桌面图标就可以启动 OpenCode！

### 16. Windows Terminal 如何配置 OpenCode 快捷启动？

在 Windows Terminal 的 `settings.json` 中添加配置：

```json
{
    "profiles": {
        "list": [
            {
                "name": "OpenCode",
                "commandline": "powershell.exe -NoExit -Command \"$env:ANTHROPIC_BASE_URL='https://tiantianai.pro/v1'; $env:ANTHROPIC_API_KEY='your-key'; opencode\"",
                "icon": "🤖",
                "startingDirectory": "%USERPROFILE%",
                "colorScheme": "One Half Dark"
            }
        ]
    }
}
```

然后在 Windows Terminal 中就可以选择 "OpenCode" 配置文件启动。

### 17. Windows 如何在右键菜单中添加"在此处打开 OpenCode"？

**方法 1：使用注册表（推荐）**

创建 `add-opencode-context-menu.reg` 文件：

```reg
Windows Registry Editor Version 5.00

[HKEY_CLASSES_ROOT\Directory\Background\shell\OpenCode]
@="在此处打开 OpenCode"
"Icon"="C:\\Windows\\System32\\cmd.exe"

[HKEY_CLASSES_ROOT\Directory\Background\shell\OpenCode\command]
@="powershell.exe -NoExit -Command \"$env:ANTHROPIC_BASE_URL='https://tiantianai.pro/v1'; $env:ANTHROPIC_API_KEY='your-key'; Set-Location '%V'; opencode\""
```

双击运行，然后在任意文件夹空白处右键就能看到"在此处打开 OpenCode"选项。

**删除右键菜单**：

创建 `remove-opencode-context-menu.reg`：

```reg
Windows Registry Editor Version 5.00

[-HKEY_CLASSES_ROOT\Directory\Background\shell\OpenCode]
```

### 18. Windows PowerShell 配置文件在哪里？

```powershell
# 查看配置文件路径
echo $PROFILE

# 如果文件不存在，创建它
if (!(Test-Path $PROFILE)) {
    New-Item -Path $PROFILE -ItemType File -Force
}

# 编辑配置文件
notepad $PROFILE
```

常见的配置文件位置：
- `C:\Users\<用户名>\Documents\PowerShell\Microsoft.PowerShell_profile.ps1` (PowerShell 7+)
- `C:\Users\<用户名>\Documents\WindowsPowerShell\Microsoft.PowerShell_profile.ps1` (Windows PowerShell 5.1)

### 19. Windows 如何设置开机自动配置环境变量？

环境变量设置后是永久的，不需要开机自动配置。如果你想在每次打开 PowerShell 时自动显示配置信息，可以在 PowerShell 配置文件中添加：

```powershell
# 编辑配置文件
notepad $PROFILE

# 添加以下内容
Write-Host "OpenCode 环境变量已配置:" -ForegroundColor Green
Write-Host "  Base URL: $env:ANTHROPIC_BASE_URL" -ForegroundColor Cyan
Write-Host "  API Key: $($env:ANTHROPIC_API_KEY.Substring(0,20))..." -ForegroundColor Cyan
Write-Host ""
Write-Host "快捷命令:" -ForegroundColor Yellow
Write-Host "  oc        - 启动 OpenCode" -ForegroundColor Gray
Write-Host "  oc-opus   - 使用 Opus 4.5 模型" -ForegroundColor Gray
Write-Host "  oc-sonnet - 使用 Sonnet 4.5 模型" -ForegroundColor Gray
Write-Host ""

# 定义快捷函数
function oc { opencode $args }
function oc-opus { opencode -m anthropic/claude-opus-4-5-20251101 $args }
function oc-sonnet { opencode -m anthropic/claude-sonnet-4-5 $args }
```

### 20. Windows 环境变量和配置文件哪个优先级更高？

**优先级顺序**（从高到低）：

1. **当前 PowerShell 会话中设置的环境变量**
   ```powershell
   $env:ANTHROPIC_API_KEY = "temp-key"
   ```

2. **用户级环境变量**（通过系统设置或 `SetEnvironmentVariable` 设置）

3. **配置文件** (`~/.opencode.json`)

**推荐使用场景**：
- 日常使用 → 用户级环境变量（永久生效）
- 临时测试 → 当前会话环境变量
- 复杂配置 → 配置文件（支持多 provider）

---

## 参考资源

- **官方文档**: [opencode.ai/docs](https://opencode.ai/docs)
- **GitHub 仓库**: [github.com/anomalyco/opencode](https://github.com/anomalyco/opencode)
- **问题反馈**: [GitHub Issues](https://github.com/anomalyco/opencode/issues)
- **中文 README**: [README.zh.md](https://github.com/anomalyco/opencode/blob/dev/README.zh.md)

---

## 贡献与支持

OpenCode 是 100% 开源项目，欢迎贡献代码和反馈问题。

如需帮助，请访问：
- [官方文档](https://opencode.ai/docs)
- [GitHub Discussions](https://github.com/anomalyco/opencode/discussions)
- [Discord 社区](https://discord.gg/opencode)（如有）

---

**最后更新**: 2026-01-28
