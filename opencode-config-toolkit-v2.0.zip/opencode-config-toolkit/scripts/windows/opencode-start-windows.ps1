# OpenCode 启动脚本 (Windows)
# 使用方法：powershell -File opencode-start-windows.ps1

# 配置 API 信息（请修改为你的实际信息）
$env:ANTHROPIC_BASE_URL = "https://tiantianai.pro/v1"
$env:ANTHROPIC_API_KEY = "sk-NFnWE5NQfs2tcGuVeIIVsSNA7LZMLcBGzV4HVJFioiWn3O0c"

# 显示配置信息
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   OpenCode 启动脚本" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "已配置自定义 API:" -ForegroundColor Green
Write-Host "  Base URL: $env:ANTHROPIC_BASE_URL" -ForegroundColor Cyan
Write-Host "  API Key: $($env:ANTHROPIC_API_KEY.Substring(0,20))..." -ForegroundColor Cyan
Write-Host ""

# 检查 OpenCode 是否已安装
if (-not (Get-Command opencode -ErrorAction SilentlyContinue)) {
    Write-Host "错误：OpenCode 未安装！" -ForegroundColor Red
    Write-Host ""
    Write-Host "请先安装 OpenCode：" -ForegroundColor Yellow
    Write-Host "  npm install -g opencode-ai@latest" -ForegroundColor White
    Write-Host ""
    pause
    exit 1
}

# 如果没有指定模型，使用默认模型
if ($args -notcontains "-m" -and $args -notcontains "--model") {
    Write-Host "使用默认模型: claude-opus-4-5-20251101" -ForegroundColor Yellow
    Write-Host "提示: 使用 -m 参数可以指定其他模型" -ForegroundColor Gray
    Write-Host ""
    Write-Host "启动 OpenCode..." -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    opencode -m anthropic/claude-opus-4-5-20251101 $args
} else {
    Write-Host "启动 OpenCode..." -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    opencode $args
}
