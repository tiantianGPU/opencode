#!/bin/bash

# OpenCode 自定义 API 配置脚本
# 使用你的 tiantianai.pro API

export ANTHROPIC_BASE_URL="https://tiantianai.pro/v1"
export ANTHROPIC_API_KEY="sk-NFnWE5NQfs2tcGuVeIIVsSNA7LZMLcBGzV4HVJFioiWn3O0c"

echo "已配置自定义 API:"
echo "  Base URL: $ANTHROPIC_BASE_URL"
echo "  API Key: ${ANTHROPIC_API_KEY:0:20}..."
echo ""

# 如果没有指定模型，使用默认模型
if [[ "$*" != *"-m"* ]] && [[ "$*" != *"--model"* ]]; then
    echo "使用默认模型: claude-opus-4-5-20251101"
    echo "提示: 使用 -m 参数可以指定其他模型"
    echo ""
    opencode -m anthropic/claude-opus-4-5-20251101 "$@"
else
    echo "启动 opencode..."
    echo ""
    opencode "$@"
fi
